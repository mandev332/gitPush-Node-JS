let sanoq = () => {
  return 1;
};
let sana = sanoq();
