let x = 19;
function son() {
  let n = 10;
  return n;
}
son();
function jami() {
  return 5 * 6;
}
